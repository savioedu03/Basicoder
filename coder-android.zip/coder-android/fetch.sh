#!/bin/bash
# Baixa proot (Termux) e descobre a URL do rootfs Debian. Roda no GitHub Actions.
set -e
P=$(cd "$(dirname "$0")" && pwd)
J=$P/app/src/main/jniLibs/arm64-v8a
mkdir -p "$J" /tmp/w && cd /tmp/w
T=https://packages.termux.dev/apt/termux-main/pool/main
get() {
  f=$(curl -s $T/$1/ | grep -o 'href="[^"]*aarch64\.deb"' | sed 's/href="//;s/"//' | sort -V | tail -1)
  [ -n "$f" ] || { echo "pacote nao encontrado: $1"; exit 1; }
  curl -sLO "$T/$1/$f"; ar x "$f"; mkdir -p "$2"
  tar xf data.tar.* -C "$2"; rm -f data.tar.* control.tar.* debian-binary
}
get p/proot proot
get libt/libtalloc talloc
get liba/libandroid-shmem shmem
cp "$(find proot -path '*/bin/proot')" "$J/libproot.so"
cp "$(find proot -path '*/libexec/proot/loader')" "$J/libproot-loader.so"
cp -L "$(find talloc -name 'libtalloc.so.2*' -type f | head -1)" "$J/libtalloc.so"
cp -L "$(find shmem -name 'libandroid-shmem.so*' \( -type f -o -type l \) | head -1)" "$J/libandroid-shmem.so"
echo "Dependencias do proot:"; readelf -d "$J/libproot.so" | grep NEEDED || true
U=$(curl -s "https://api.github.com/repos/termux/proot-distro/releases?per_page=40" | jq -r '[.[].assets[]|select(.name|test("^debian-.*aarch64.*tar\\.xz$"))|select(.name|test("oldstable")|not)][0].browser_download_url')
echo "Rootfs: $U"
[ -n "$U" ] && [ "$U" != null ]
curl -sL "$U" -o r.tar.xz
if tar -tf r.tar.xz | head -100 | grep -qE '^(\./)?(usr|bin|etc)/'; then S=0; else S=1; fi
sed -i "s|^const val ROOTFS_URL = .*|const val ROOTFS_URL = \"$U\"|;s|^const val STRIP = .*|const val STRIP = $S|" "$P/app/src/main/java/dev/coder/MainActivity.kt"
