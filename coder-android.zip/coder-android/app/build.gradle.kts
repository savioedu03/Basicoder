plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "dev.coder"
    compileSdk = 35
    defaultConfig {
        applicationId = "dev.coder"; minSdk = 26; targetSdk = 35
        versionCode = 1; versionName = "0.1"
        ndk { abiFilters += "arm64-v8a" }
    }
    // necessario: extrai os .so (proot) para nativeLibraryDir, onde o Android permite executar
    packaging { jniLibs { useLegacyPackaging = true } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("org.apache.commons:commons-compress:1.27.1")
    implementation("org.tukaani:xz:1.10")
}
