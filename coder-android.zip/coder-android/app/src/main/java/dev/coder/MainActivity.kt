package dev.coder

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.WindowInsets
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.FrameLayout
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStreamReader
import java.net.URL
import java.nio.file.Files
import java.nio.file.Paths
import java.util.Date
import kotlin.concurrent.thread

// >>> AJUSTE (o fetch.sh preenche automaticamente no GitHub)
const val ROOTFS_URL = "COLE_AQUI_A_URL_DO_ROOTFS_DEBIAN_AARCH64.tar.xz"
const val STRIP = 1
val CODER_DIR = File(Environment.getExternalStorageDirectory(), "coder")

fun logErr(ctx: Context, e: Throwable) {
    try { File(ctx.filesDir, "errors.log").appendText("${Date()}\n${e.stackTraceToString()}\n") } catch (_: Throwable) {}
}

class MainActivity : Activity() {
    private var web: WebView? = null
    private var askedPerm = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e -> logErr(this, e); prev?.uncaughtException(t, e) }
        if (!Environment.isExternalStorageManager()) {
            askedPerm = true
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } else CODER_DIR.mkdirs()
        val w = WebView(this)
        web = w
        w.settings.javaScriptEnabled = true
        w.settings.setSupportZoom(false)
        w.settings.builtInZoomControls = false
        w.settings.textZoom = 100
        w.webChromeClient = WebChromeClient()
        w.addJavascriptInterface(Bridge(this, w), "Android")
        w.loadUrl("file:///android_asset/index.html")
        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF1E1F22.toInt())
        root.addView(w)
        root.setOnApplyWindowInsetsListener { v, ins ->
            if (Build.VERSION.SDK_INT >= 30) {
                val i = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                v.setPadding(i.left, i.top, i.right, i.bottom)
                WindowInsets.CONSUMED
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
                @Suppress("DEPRECATION")
                ins.consumeSystemWindowInsets()
            }
        }
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (askedPerm && Environment.isExternalStorageManager()) {
            askedPerm = false; CODER_DIR.mkdirs(); web?.reload()
        }
    }

    override fun onPause() {
        web?.evaluateJavascript("window.flushState&&flushState()", null)
        super.onPause()
    }

    override fun onBackPressed() {}
}

class Shell(private val act: Activity) {
    private val base = act.filesDir
    private val rootfs = File(base, "rootfs")
    private var proc: Process? = null
    fun ready() = File(rootfs, "usr/bin/bash").exists()
    fun hasTools() = File(rootfs, "usr/bin/g++").exists()
    fun alive() = proc?.isAlive == true

    fun builder(cwd: String, vararg tail: String): ProcessBuilder {
        val nl = act.applicationInfo.nativeLibraryDir
        val lib = File(base, "lib").apply { mkdirs() }
        val l = File(lib, "libtalloc.so.2")
        // o caminho das libs muda a cada atualizacao do app: recria o link sempre
        if (File(nl, "libtalloc.so").exists()) {
            Files.deleteIfExists(l.toPath())
            Files.createSymbolicLink(l.toPath(), Paths.get(nl, "libtalloc.so"))
        }
        val cmd = mutableListOf(
            "$nl/libproot.so", "-0", "--link2symlink", "--kill-on-exit", "-r", rootfs.path,
            "-b", "${CODER_DIR.path}:/coder", "-b", "/dev", "-b", "/proc", "-b", "/sys", "-w", cwd,
            "/usr/bin/env", "-i", "HOME=/root", "TERM=dumb", "LANG=C.UTF-8", "PYTHONUNBUFFERED=1", "PYTHONIOENCODING=utf-8",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
        )
        cmd.addAll(tail)
        val pb = ProcessBuilder(cmd)
        pb.environment().apply {
            put("PROOT_LOADER", "$nl/libproot-loader.so")
            put("PROOT_TMP_DIR", File(base, "tmp").apply { mkdirs() }.path)
            put("LD_LIBRARY_PATH", "$nl:${lib.path}")
        }
        pb.redirectErrorStream(true)
        return pb
    }

    fun pump(p: Process, onOut: (String) -> Unit, onEnd: (Int) -> Unit) {
        thread {
            try {
                val r = InputStreamReader(p.inputStream, Charsets.UTF_8)
                val b = CharArray(4096)
                while (true) { val n = r.read(b); if (n < 0) break; onOut(String(b, 0, n)) }
            } catch (e: Throwable) { logErr(act, e) }
            onEnd(try { p.waitFor() } catch (e: Throwable) { -1 })
        }
    }

    fun start(onOut: (String) -> Unit) {
        if (proc?.isAlive == true) return
        val p = builder("/coder", "/bin/bash", "-l").start()
        proc = p
        pump(p, onOut) { onOut("\n[terminal encerrado]\n") }
    }

    fun send(s: String) { proc?.outputStream?.apply { write(s.toByteArray()); flush() } }

    fun install(log: (String) -> Unit) {
        val tar = File(base, "rootfs.tar.xz")
        log("Baixando Debian...\n")
        URL(ROOTFS_URL).openStream().use { i -> tar.outputStream().use { i.copyTo(it) } }
        log("Extraindo (pode demorar)...\n")
        fun strip(n: String) = n.split('/').filter { it.isNotEmpty() && it != "." }.drop(STRIP).joinToString("/")
        TarArchiveInputStream(XZCompressorInputStream(tar.inputStream().buffered())).use { t ->
            var e = t.nextTarEntry
            while (e != null) {
                val name = strip(e.name)
                val f = File(rootfs, name)
                if (name.isNotEmpty() && f.toPath().normalize().startsWith(rootfs.toPath())) {
                    f.parentFile?.mkdirs()
                    when {
                        e.isDirectory -> { f.mkdirs(); f.setReadable(true); f.setWritable(true); f.setExecutable(true) }
                        e.isSymbolicLink -> { Files.deleteIfExists(f.toPath()); Files.createSymbolicLink(f.toPath(), Paths.get(e.linkName)) }
                        e.isLink -> File(rootfs, strip(e.linkName)).copyTo(f, true)
                        else -> {
                            f.outputStream().use { t.copyTo(it) }
                            f.setReadable(true); f.setWritable(true)
                            if ((e.mode and 0x49) != 0) f.setExecutable(true)
                        }
                    }
                }
                e = t.nextTarEntry
            }
        }
        tar.delete()
        File(rootfs, "etc/resolv.conf").apply { delete(); writeText("nameserver 8.8.8.8\n") }
    }
}

class Bridge(private val act: Activity, private val web: WebView) {
    private val shell = Shell(act)
    private var job: Process? = null
    private val E = "\u0001"

    private fun js(code: String) = act.runOnUiThread { web.evaluateJavascript(code, null) }
    private fun q(s: String) = JSONObject.quote(s)
    private fun term(s: String) = js("term(${q(s)})")
    private fun guard(block: () -> String): String =
        try { block() } catch (e: Throwable) { logErr(act, e); E + (e.message ?: e.toString()) }
    private fun ok(block: () -> Unit) = guard { block(); "ok" }
    private fun safe(p: String): File {
        val f = File(CODER_DIR.parentFile, p).canonicalFile
        require(f.path == CODER_DIR.path || f.path.startsWith(CODER_DIR.path + "/")) { "caminho invalido" }
        return f
    }

    @JavascriptInterface fun status(): String = guard {
        when {
            !Environment.isExternalStorageManager() -> "perm"
            !shell.hasTools() -> "nosys"
            else -> "ok"
        }
    }
    @JavascriptInterface fun list(path: String): String = guard {
        val a = JSONArray()
        safe(path).listFiles()?.filter { !it.name.startsWith(".trashed-") }
            ?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
            ?.forEach { a.put(JSONObject().put("n", it.name).put("d", it.isDirectory)) }
        a.toString()
    }
    @JavascriptInterface fun read(path: String): String = guard { safe(path).readText() }
    @JavascriptInterface fun exists(path: String): Boolean = try { safe(path).exists() } catch (e: Throwable) { false }
    @JavascriptInterface fun write(path: String, text: String): String = ok { safe(path).writeText(text) }
    @JavascriptInterface fun create(path: String, dir: Boolean): String = ok {
        val f = safe(path); if (dir) f.mkdirs() else { f.parentFile?.mkdirs(); f.createNewFile() }
    }
    @JavascriptInterface fun rename(path: String, name: String): String = ok {
        val f = safe(path); check(f.renameTo(File(f.parentFile, name))) { "nao foi possivel renomear" }
    }
    @JavascriptInterface fun remove(path: String): String = ok { check(safe(path).deleteRecursively()) { "falha ao excluir" } }

    // rascunhos e estado do editor (nunca tocam nos arquivos originais)
    @JavascriptInterface fun saveState(s: String): String = ok {
        val t = File(act.filesDir, "state.tmp"); t.writeText(s); t.renameTo(File(act.filesDir, "state.json"))
    }
    @JavascriptInterface fun loadState(): String = guard {
        File(act.filesDir, "state.json").takeIf { it.exists() }?.readText() ?: ""
    }
    @JavascriptInterface fun errlog(): String = guard {
        File(act.filesDir, "errors.log").takeIf { it.exists() }?.readText()?.takeLast(4000) ?: "(sem erros registrados)"
    }

    // terminal persistente (apt, pip...)
    @JavascriptInterface fun start(): String = ok { shell.start { s -> term(s) } }
    @JavascriptInterface fun exec(line: String) { try { if (!shell.alive()) shell.start { s -> term(s) }; shell.send(line) } catch (e: Throwable) { logErr(act, e) } }

    // programas do F5/F8/F9: um processo por execucao
    @JavascriptInterface fun runJob(id: Int, cwd: String, cmd: String): String = guard {
        if (job?.isAlive == true) return@guard "busy"
        val p = shell.builder(cwd, "/bin/bash", "-c", cmd).start()
        job = p
        shell.pump(p, { s -> js("jobOut($id,${q(s)})") }) { code -> js("jobEnd($id,$code)") }
        "ok"
    }
    @JavascriptInterface fun jobIn(s: String) { try { job?.outputStream?.apply { write(s.toByteArray()); flush() } } catch (e: Throwable) { logErr(act, e) } }
    @JavascriptInterface fun stopJob(): String = guard {
        val p = job
        if (p != null && p.isAlive) { p.destroyForcibly(); "killed" } else "none"
    }

    @JavascriptInterface fun setup() {
        thread {
            try {
                if (!shell.ready()) shell.install { s -> term(s) }
                shell.start { s -> term(s) }
                shell.send("echo 'APT::Sandbox::User \"root\";' > /etc/apt/apt.conf.d/01proot\n")
                shell.send("printf '[global]\\nbreak-system-packages = true\\n' > /etc/pip.conf\n")
                shell.send("apt update && apt install -y python3 python3-pip python3-venv g++ make gdb default-jdk-headless && echo '=== PRONTO ==='\n")
            } catch (e: Throwable) { logErr(act, e); term("Erro: ${e.message}\n") }
        }
    }
}
