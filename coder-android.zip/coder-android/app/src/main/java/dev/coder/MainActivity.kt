package dev.coder

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.Environment
import android.view.WindowInsets
import android.widget.FrameLayout
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URL
import java.nio.file.Files
import java.nio.file.Paths
import kotlin.concurrent.thread

// >>> AJUSTE: URL do rootfs Debian (arm64, .tar.xz) e quantos niveis de pasta remover ao extrair
const val ROOTFS_URL = "COLE_AQUI_A_URL_DO_ROOTFS_DEBIAN_AARCH64.tar.xz"
const val STRIP = 1
val CODER_DIR = File(Environment.getExternalStorageDirectory(), "coder")

class MainActivity : Activity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!Environment.isExternalStorageManager())
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        else CODER_DIR.mkdirs()
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.webChromeClient = WebChromeClient() // habilita prompt()/confirm()
        web.addJavascriptInterface(Bridge(this, web), "Android")
        web.loadUrl("file:///android_asset/index.html")
        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF1E1F22.toInt())
        root.addView(web)
        // evita que o app fique sob as barras do sistema e acompanha o teclado
        root.setOnApplyWindowInsetsListener { v, ins ->
            if (Build.VERSION.SDK_INT >= 30) {
                val i = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                v.setPadding(i.left, i.top, i.right, i.bottom)
                WindowInsets.CONSUMED
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
                @Suppress("DEPRECATION")
                ins.consumeSystemWindowInsets()
            }
        }
        setContentView(root)
    }
    override fun onBackPressed() {}
}

class Shell(private val act: Activity, private val onOut: (String) -> Unit) {
    private val base = act.filesDir
    private val rootfs = File(base, "rootfs")
    private var proc: Process? = null
    fun ready() = File(rootfs, "usr/bin/bash").exists()
    fun hasTools() = File(rootfs, "usr/bin/g++").exists()

    fun start() {
        if (proc?.isAlive == true) return
        val nl = act.applicationInfo.nativeLibraryDir
        val lib = File(base, "lib").apply { mkdirs() }
        // o proot do Termux procura por libtalloc.so.2
        val l = File(lib, "libtalloc.so.2")
        if (!l.exists() && File(nl, "libtalloc.so").exists()) Files.createSymbolicLink(l.toPath(), Paths.get(nl, "libtalloc.so"))
        val pb = ProcessBuilder(
            "$nl/libproot.so", "-0", "--link2symlink", "--kill-on-exit", "-r", rootfs.path,
            "-b", "${CODER_DIR.path}:/coder", "-b", "/dev", "-b", "/proc", "-b", "/sys", "-w", "/coder",
            "/usr/bin/env", "-i", "HOME=/root", "TERM=dumb", "PYTHONUNBUFFERED=1",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin", "/bin/bash", "-l"
        )
        pb.environment().apply {
            put("PROOT_LOADER", "$nl/libproot-loader.so")
            put("PROOT_TMP_DIR", File(base, "tmp").apply { mkdirs() }.path)
            put("LD_LIBRARY_PATH", "$nl:${lib.path}")
        }
        pb.redirectErrorStream(true)
        val p = pb.start(); proc = p
        thread {
            val b = ByteArray(4096)
            while (true) { val n = p.inputStream.read(b); if (n < 0) break; onOut(String(b, 0, n)) }
            onOut("\n[shell encerrado]\n")
        }
    }

    fun stop() { proc?.destroyForcibly(); proc = null; start() }

    fun send(s: String) { proc?.outputStream?.apply { write(s.toByteArray()); flush() } }

    fun install(log: (String) -> Unit) {
        val tar = File(base, "rootfs.tar.xz")
        log("Baixando Debian...\n")
        URL(ROOTFS_URL).openStream().use { i -> tar.outputStream().use { i.copyTo(it) } }
        log("Extraindo (pode demorar)...\n")
        fun strip(n: String) = n.split('/').filter { it.isNotEmpty() && it != "." }.drop(STRIP).joinToString("/")
        TarArchiveInputStream(XZCompressorInputStream(tar.inputStream().buffered())).use { t ->
            var e = t.nextTarEntry
            while (e != null) {
                val name = strip(e.name)
                val f = File(rootfs, name)
                if (name.isNotEmpty() && f.toPath().normalize().startsWith(rootfs.toPath())) {
                    f.parentFile?.mkdirs()
                    when {
                        e.isDirectory -> { f.mkdirs(); f.setReadable(true); f.setWritable(true); f.setExecutable(true) }
                        e.isSymbolicLink -> { Files.deleteIfExists(f.toPath()); Files.createSymbolicLink(f.toPath(), Paths.get(e.linkName)) }
                        e.isLink -> File(rootfs, strip(e.linkName)).copyTo(f, true)
                        else -> {
                            f.outputStream().use { t.copyTo(it) }
                            f.setReadable(true); f.setWritable(true)
                            if ((e.mode and 0x49) != 0) f.setExecutable(true)
                        }
                    }
                }
                e = t.nextTarEntry
            }
        }
        tar.delete()
        File(rootfs, "etc/resolv.conf").apply { delete(); writeText("nameserver 8.8.8.8\n") }
    }
}

class Bridge(private val act: Activity, private val web: WebView) {
    private val shell = Shell(act) { s -> act.runOnUiThread { web.evaluateJavascript("term(${JSONObject.quote(s)})", null) } }

    private fun safe(p: String): File {
        val f = File(CODER_DIR.parentFile, p).canonicalFile
        require(f.path == CODER_DIR.path || f.path.startsWith(CODER_DIR.path + "/")) { "caminho invalido" }
        return f
    }
    private fun ok(block: () -> Unit) = try { block(); "ok" } catch (e: Exception) { "Erro: ${e.message}" }

    @JavascriptInterface fun status(): String = when {
        !Environment.isExternalStorageManager() -> "perm"
        !shell.hasTools() -> "nosys"
        else -> "ok"
    }
    @JavascriptInterface fun list(path: String): String {
        val a = JSONArray()
        safe(path).listFiles()?.filter { !it.name.startsWith(".trashed-") }?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))?.forEach {
            a.put(JSONObject().put("n", it.name).put("d", it.isDirectory))
        }
        return a.toString()
    }
    @JavascriptInterface fun read(path: String) = safe(path).readText()
    @JavascriptInterface fun write(path: String, text: String) = ok { safe(path).writeText(text) }
    @JavascriptInterface fun create(path: String, dir: Boolean) = ok {
        val f = safe(path); if (dir) f.mkdirs() else { f.parentFile?.mkdirs(); f.createNewFile() }
    }
    @JavascriptInterface fun rename(path: String, name: String) = ok {
        val f = safe(path); check(f.renameTo(File(f.parentFile, name))) { "nao foi possivel renomear" }
    }
    @JavascriptInterface fun remove(path: String) = ok { check(safe(path).deleteRecursively()) { "falha ao excluir" } }

    @JavascriptInterface fun start() = ok { shell.start() }
    @JavascriptInterface fun stop() { thread { shell.stop() } }
    @JavascriptInterface fun exec(line: String) { shell.send(line) }
    @JavascriptInterface fun setup() {
        thread {
            val log = { s: String -> act.runOnUiThread { web.evaluateJavascript("term(${JSONObject.quote(s)})", null) } }
            try {
                if (!shell.ready()) shell.install(log)
                shell.start()
                shell.send("echo 'APT::Sandbox::User \"root\";' > /etc/apt/apt.conf.d/01proot\n")
                shell.send("printf '[global]\\nbreak-system-packages = true\\n' > /etc/pip.conf\n")
                shell.send("apt update && apt install -y python3 python3-pip python3-venv g++ make gdb default-jdk-headless && echo '=== PRONTO ==='\n")
            } catch (e: Exception) { log("Erro: ${e.message}\n") }
        }
    }
}
