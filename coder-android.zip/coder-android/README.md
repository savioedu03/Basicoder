# Coder (esqueleto)

Editor + terminal com Debian embutido (proot). NÃO foi compilado nem testado: espere pequenos ajustes.

## Passos
1. Abra esta pasta no Android Studio (ele cria o gradle wrapper) e deixe sincronizar.
2. Coloque em `app/src/main/jniLibs/arm64-v8a/` (arquivos do pacote `proot` aarch64 do Termux, renomeados):
   - `proot` -> `libproot.so`
   - `libexec/proot/loader` -> `libproot-loader.so`
   - `libtalloc.so.2` -> `libtalloc.so`
3. Em `MainActivity.kt`, defina `ROOTFS_URL` (rootfs Debian arm64 .tar.xz) e ajuste `STRIP`
   (1 = o tar tem uma pasta raiz; 0 = `bin/`, `etc/` na raiz).
4. Build > Build APK, copie o APK para o tablet e instale.
5. Abra o app, conceda "Acesso a todos os arquivos", digite `instalar` no terminal e aguarde `=== PRONTO ===`.
6. Android 14+: Opções do desenvolvedor > "Desativar restrições de processos secundários".

## Notas
- Pasta de trabalho: /storage/emulated/0/coder (dentro do Debian: /coder). Binários vão para /tmp (interno).
- Versões: o Debian estável define Python/g++/OpenJDK; confira com `python3 -V`, `g++ -V`, `java -version`.
- pip já instala sem --break-system-packages (configurado em /etc/pip.conf).
- Sem pty: programas interativos simples (cin, input) funcionam; vim/htop não.
- Atalhos: F5/F8/F9, Ctrl+S/C/X/V/Z/Y, Tab = 4 espaços.
